﻿using System.Windows;

namespace ARCRaidersUtility
{
    public partial class App : Application
    {
    }
}
