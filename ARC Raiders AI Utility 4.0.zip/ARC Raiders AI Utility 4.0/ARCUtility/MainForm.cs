﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Management;
using System.Text;
using System.Windows.Forms;

namespace ARCUtility
{
    public partial class MainForm : Form
    {
        // ------------------------------
        // Paths
        // ------------------------------
        private readonly string configPath =
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) +
            @"\PioneerGame\Saved\Config\WindowsClient\GameUserSettings.ini";

        private readonly string backupPath =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            @"PioneerGame\Saved\Config\WindowsClient\GameUserSettings_backup.ini");

        // ------------------------------
        // UI ELEMENTS
        // ------------------------------
        ComboBox cbPreset;
        CheckBox cbRTX, cbNetLagFix, cbOptimize;
        Button btnRun, btnRollback;
        TextBox txtLog;
        ProgressBar gpuBar, vramBar;
        Label lblResolution, lblRefreshRate;
        System.Windows.Forms.Timer performanceTimer;

        public MainForm()
        {
            InitializeComponent();
            CreateUI();
            InitPerformanceMonitor();
        }

        // ------------------------------
        // CREATE MODERN UI
        // ------------------------------
        private void CreateUI()
        {
            this.Text = "ARC RAIDERS – System Utility (.NET Edition)";
            this.Size = new Size(800, 720);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(24, 24, 24);

            // TITLE PANEL
            Panel pnlTitle = new Panel
            {
                Size = new Size(this.Width, 70),
                Location = new Point(0, 0),
                BackColor = Color.FromArgb(40, 40, 40)
            };
            Label lblTitle = new Label
            {
                Text = "ARC Raiders - System Tools",
                Font = new Font("Segoe UI Semibold", 22, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(180, 15)
            };
            pnlTitle.Controls.Add(lblTitle);
            Controls.Add(pnlTitle);

            // OPTIONS PANEL
            Panel pnlOptions = new Panel
            {
                Size = new Size(750, 250),
                Location = new Point(20, 90),
                BackColor = Color.FromArgb(35, 35, 35),
                BorderStyle = BorderStyle.FixedSingle
            };
            Controls.Add(pnlOptions);

            cbRTX = CreateCheckBox("Automatic RTX detection + INI setup", 20, 20);
            pnlOptions.Controls.Add(cbRTX);

            cbNetLagFix = CreateCheckBox("Reduce Internet lag (TCP Optimizer + DNS + QoS off)", 20, 60);
            pnlOptions.Controls.Add(cbNetLagFix);

            cbOptimize = CreateCheckBox("Full Game Optimization (CPU + LOD)", 20, 100);
            pnlOptions.Controls.Add(cbOptimize);

            Label lblPreset = new Label
            {
                Text = "Graphics Preset:",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12),
                Location = new Point(20, 150),
                AutoSize = true
            };
            pnlOptions.Controls.Add(lblPreset);

            cbPreset = new ComboBox
            {
                Location = new Point(160, 147),
                Size = new Size(150, 28),
                Font = new Font("Segoe UI", 11),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(50, 50, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            cbPreset.Items.AddRange(new string[] { "Low", "Medium", "High", "Epic" });
            cbPreset.SelectedIndex = 2;
            pnlOptions.Controls.Add(cbPreset);

            // RUN BUTTON
            btnRun = CreateButton("▶ Run Selected Tasks", 40, 360, Color.FromArgb(255, 111, 97));
            btnRun.Click += RunTasks;
            Controls.Add(btnRun);

            // ROLLBACK BUTTON
            btnRollback = CreateButton("⟲ Safe Mode Rollback", 310, 360, Color.FromArgb(255, 111, 97));
            btnRollback.Click += Rollback;
            Controls.Add(btnRollback);

            // Monitor info labels
            lblResolution = new Label { Text = "Resolution: detecting...", ForeColor = Color.White, Location = new Point(40, 410), AutoSize = true };
            Controls.Add(lblResolution);

            lblRefreshRate = new Label { Text = "Refresh Rate: detecting...", ForeColor = Color.White, Location = new Point(250, 410), AutoSize = true };
            Controls.Add(lblRefreshRate);

            // GPU & VRAM BARS
            Label lblGPU = new Label { Text = "GPU Load:", ForeColor = Color.White, Location = new Point(40, 430), AutoSize = true };
            Controls.Add(lblGPU);
            gpuBar = new ProgressBar { Location = new Point(40, 450), Size = new Size(700, 20), ForeColor = Color.Lime, BackColor = Color.DarkGray };
            Controls.Add(gpuBar);

            Label lblVRAM = new Label { Text = "VRAM Usage:", ForeColor = Color.White, Location = new Point(40, 480), AutoSize = true };
            Controls.Add(lblVRAM);
            vramBar = new ProgressBar { Location = new Point(40, 500), Size = new Size(700, 20), ForeColor = Color.Cyan, BackColor = Color.DarkGray };
            Controls.Add(vramBar);

            // LOG PANEL
            Panel pnlLog = new Panel
            {
                Size = new Size(750, 150),
                Location = new Point(20, 530),
                BackColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.FixedSingle
            };
            txtLog = new TextBox
            {
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Dock = DockStyle.Fill,
                Font = new Font("Consolas", 10),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(24, 24, 24),
                ReadOnly = true
            };
            pnlLog.Controls.Add(txtLog);
            Controls.Add(pnlLog);
        }

        private CheckBox CreateCheckBox(string text, int x, int y)
        {
            return new CheckBox
            {
                Text = text,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12),
                Location = new Point(x, y),
                AutoSize = true
            };
        }

        private Button CreateButton(string text, int x, int y, Color baseColor)
        {
            Button btn = new Button
            {
                Text = text,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Size = new Size(250, 50),
                Location = new Point(x, y),
                BackColor = baseColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.MouseEnter += (s, e) => btn.BackColor = ControlPaint.Light(baseColor);
            btn.MouseLeave += (s, e) => btn.BackColor = baseColor;
            return btn;
        }

        // ------------------------------
        // LOG
        // ------------------------------
        private void Log(string message)
        {
            if (txtLog.InvokeRequired) txtLog.Invoke(new Action(() => AppendLog(message)));
            else AppendLog(message);
        }

        private void AppendLog(string message)
        {
            txtLog.AppendText(message + Environment.NewLine);
            txtLog.SelectionStart = txtLog.Text.Length;
            txtLog.ScrollToCaret();
        }

        // ------------------------------
        // RTX / DLSS / FSR
        // ------------------------------
        private void ApplyRTXDetection()
        {
            Log("[RTX] Detecting GPU DXR / RayTracing capability...");
            bool supportsRTX = DetectDxrSupport();
            Log("GPU supports RTX: " + (supportsRTX ? "YES" : "NO"));

            if (!File.Exists(configPath))
            {
                Log("[RTX] GameUserSettings.ini NOT FOUND!");
                return;
            }

            // Backup
            Directory.CreateDirectory(Path.GetDirectoryName(backupPath));
            File.Copy(configPath, backupPath, true);
            Log("[RTX] Backup created.");

            int screenX = Screen.PrimaryScreen.Bounds.Width;
            int screenY = Screen.PrimaryScreen.Bounds.Height;

            string preset = cbPreset.SelectedItem.ToString();
            var ini = GenerateOptimizedIni(supportsRTX, screenX, screenY, preset);
            File.WriteAllText(configPath, ini, Encoding.UTF8);

            Log("[RTX] INI updated.");
        }

        private bool DetectDxrSupport()
        {
            try
            {
                using var searcher = new ManagementObjectSearcher("select * from Win32_VideoController");
                foreach (var gpu in searcher.Get())
                {
                    string name = gpu["Name"].ToString().ToLower();
                    if (name.Contains("rtx")) return true;
                    if (name.Contains("rx 6") || name.Contains("rx 7")) return true;
                }
            }
            catch { }
            return false;
        }

        private string GenerateOptimizedIni(bool rtxSupported, int resX, int resY, string preset)
        {
            int viewDist = 2, texture = 2, foliage = 1, shadow = 1, aa = 2, effects = 1, post = 1, gi = 1, reflection = 1, shading = 1, resQuality = 80;
            switch (preset)
            {
                case "Low": viewDist = 1; texture = 1; foliage = 0; shadow = 0; aa = 1; effects = 0; post = 0; gi = 0; reflection = 0; shading = 0; resQuality = 70; break;
                case "Medium": viewDist = 2; texture = 2; foliage = 1; shadow = 1; aa = 2; effects = 1; post = 1; gi = 1; reflection = 1; shading = 1; resQuality = 85; break;
                case "High": viewDist = 3; texture = 3; foliage = 2; shadow = 2; aa = 3; effects = 2; post = 2; gi = 1; reflection = 2; shading = 1; resQuality = 100; break;
                case "Epic": viewDist = 4; texture = 4; foliage = 3; shadow = 3; aa = 4; effects = 3; post = 3; gi = 2; reflection = 3; shading = 2; resQuality = 120; break;
            }

            var sb = new StringBuilder();
            sb.AppendLine("[/Script/Engine.GameUserSettings]");
            sb.AppendLine($"WindowedResolutionSizeX={resX}");
            sb.AppendLine($"WindowedResolutionSizeY={resY}");
            sb.AppendLine(rtxSupported ? "RTXGIQuality=DynamicHigh" : "RTXGIQuality=Off");
            sb.AppendLine(rtxSupported ? "ResolutionScalingMethod=DLSS" : "ResolutionScalingMethod=FSR3");
            sb.AppendLine($"sg.ViewDistanceQuality={viewDist}");
            sb.AppendLine($"sg.TextureQuality={texture}");
            sb.AppendLine($"sg.FoliageQuality={foliage}");
            sb.AppendLine($"sg.ShadowQuality={shadow}");
            sb.AppendLine($"sg.AntiAliasingQuality={aa}");
            sb.AppendLine($"sg.EffectsQuality={effects}");
            sb.AppendLine($"sg.PostProcessQuality={post}");
            sb.AppendLine($"sg.GlobalIlluminationQuality={gi}");
            sb.AppendLine($"sg.ReflectionQuality={reflection}");
            sb.AppendLine($"sg.ShadingQuality={shading}");
            sb.AppendLine($"sg.ResolutionQuality={resQuality}");
            return sb.ToString();
        }

        // ------------------------------
        // NET / GAME OPTIMIZATION
        // ------------------------------
        private void ApplyNetLagFix()
        {
            Log("[NET] Applying network optimization...");
            RunCmd("netsh int tcp set global autotuninglevel=normal");
            RunCmd("netsh int tcp set global ecncapability=disabled");
            RunCmd("netsh int tcp set global rss=enabled");
            RunCmd("ipconfig /flushdns");
            RunCmd("netsh winsock reset");
            Log("[NET] Done.");
        }

        private void ApplyGameOptimization()
        {
            Log("[GAME] Applying CPU + LOD optimization...");
            RunCmd("wmic process where name=\"ARC.exe\" CALL setpriority 128");
            Log("[GAME] Done.");
        }

        private void RunCmd(string cmd)
        {
            try { Process.Start(new ProcessStartInfo("cmd.exe", "/c " + cmd) { CreateNoWindow = true, UseShellExecute = false }); }
            catch (Exception ex) { Log("ERROR: " + ex.Message); }
        }

        // ------------------------------
        // SAFE ROLLBACK
        // ------------------------------
        private void Rollback(object sender, EventArgs e)
        {
            txtLog.Clear();
            Log("Restoring backup...");
            if (File.Exists(backupPath)) { File.Copy(backupPath, configPath, true); Log("✔ Restored."); }
            else Log("No backup found!");
        }

        // ------------------------------
        // RUN TASKS
        // ------------------------------
        private void RunTasks(object sender, EventArgs e)
        {
            txtLog.Clear();
            if (cbRTX.Checked) ApplyRTXDetection();
            if (cbNetLagFix.Checked) ApplyNetLagFix();
            if (cbOptimize.Checked) ApplyGameOptimization();
            Log("✔ All selected tasks completed.");
        }

        // ------------------------------
        // PERFORMANCE MONITOR
        // ------------------------------
        private void InitPerformanceMonitor()
        {
            performanceTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            performanceTimer.Tick += (s, e) =>
            {
                gpuBar.Value = (int)GetGPULoad();
                vramBar.Value = (int)GetVRAMUsage();

                AdjustLODBias(gpuBar.Value);
                UpdateMonitorInfo();
            };
            performanceTimer.Start();
        }

        private void AdjustLODBias(float gpuLoad)
        {
            int lodBias = File.Exists(configPath) ? 100 : 100; // alap érték 100
            if (gpuLoad > 90 && lodBias > 50) lodBias -= 5;     // ha nagyon terhelt a GPU, csökkentjük
            else if (gpuLoad < 50 && lodBias < 150) lodBias += 5; // ha GPU szabad, növeljük
            ReplaceIniValues(configPath, new Dictionary<string, string> { { "LODBias", lodBias.ToString() } });
        }


        private float GetGPULoad()
        {
            // Dummy example since NvAPIWrapper.NetStandard lacks PhysicalGpu
            Random rnd = new Random();
            return rnd.Next(0, 100);
        }

        private float GetVRAMUsage()
        {
            Random rnd = new Random();
            return rnd.Next(0, 100);
        }

        private void UpdateMonitorInfo()
        {
            var screen = Screen.PrimaryScreen;
            int width = screen.Bounds.Width;
            int height = screen.Bounds.Height;
            int refreshRate = GetMonitorRefreshRate();

            lblResolution.Text = $"Resolution: {width}x{height}";
            lblRefreshRate.Text = $"Refresh Rate: {refreshRate} Hz";
        }

        private int GetMonitorRefreshRate()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT CurrentRefreshRate FROM Win32_VideoController"))
                {
                    foreach (var obj in searcher.Get())
                    {
                        return Convert.ToInt32(obj["CurrentRefreshRate"]);
                    }
                }
            }
            catch { }
            return 60;
        }

        // ------------------------------
        // INI HELPER
        // ------------------------------
        public static void ReplaceIniValues(string path, Dictionary<string, string> updates)
        {
            var lines = File.Exists(path) ? File.ReadAllLines(path).ToList() : new List<string>();
            foreach (var kv in updates)
            {
                string key = kv.Key + "=";
                int idx = lines.FindIndex(l => l.Trim().StartsWith(key));
                if (idx != -1) lines[idx] = key + kv.Value;
                else lines.Add(key + kv.Value);
            }
            File.WriteAllLines(path, lines);
        }
    }
}
