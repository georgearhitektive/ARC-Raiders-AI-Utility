﻿using System.Windows;

namespace ARCRaidersUtility
{
    public partial class App : Application
    {
        // Semmi extra, az OnStartup default
    }
}
