﻿using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Vortice.Direct3D12;
using Vortice.DXGI;
using System.Runtime.InteropServices;

namespace ARCRaidersUtility
{
    public partial class MainWindow : Window
    {
        private string configPath = "";
        private string backupPath = "";

        private DispatcherTimer performanceTimer;
        private Random rnd = new Random();

        public MainWindow()
        {
            InitializeComponent();

            performanceTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            performanceTimer.Tick += PerformanceTimer_Tick;
            performanceTimer.Start();

            UpdateMonitorInfo();
            TxtStatus.Text = "Status: idle";
            Log("Application started, system monitoring initialized.");
        }

        #region Performance Timer
        private void PerformanceTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                float gpuLoad = (float)rnd.NextDouble() * 100;
                PrbGpu.Value = gpuLoad;
                PrbGpu.Foreground = System.Windows.Media.Brushes.DeepSkyBlue;
                TxtGpu.Text = $"{(int)gpuLoad}%";

                float vramUsage = rnd.Next(1000, 8000);
                PrbVram.Value = Math.Min(vramUsage / 16000f * 100, 100);
                TxtVram.Text = $"{(int)vramUsage} MB";

                int refreshRate = GetPrimaryMonitorRefreshRate();
                TxtRefresh.Text = $"{refreshRate} Hz";
            }
            catch
            {
                TxtGpu.Text = "N/A";
                TxtVram.Text = "N/A";
                TxtRefresh.Text = "-- Hz";
            }
        }
        #endregion

        #region Monitor Info
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct DEVMODE
        {
            private const int CCHDEVICENAME = 32;
            private const int CCHFORMNAME = 32;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHDEVICENAME)]
            public string dmDeviceName;
            public short dmSpecVersion;
            public short dmDriverVersion;
            public short dmSize;
            public short dmDriverExtra;
            public int dmFields;
            public int dmPositionX;
            public int dmPositionY;
            public int dmDisplayOrientation;
            public int dmDisplayFixedOutput;
            public short dmColor;
            public short dmDuplex;
            public short dmYResolution;
            public short dmTTOption;
            public short dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHFORMNAME)]
            public string dmFormName;
            public short dmLogPixels;
            public int dmBitsPerPel;
            public int dmPelsWidth;
            public int dmPelsHeight;
            public int dmDisplayFlags;
            public int dmDisplayFrequency;
            public int dmICMMethod;
            public int dmICMIntent;
            public int dmMediaType;
            public int dmDitherType;
            public int dmReserved1;
            public int dmReserved2;
            public int dmPanningWidth;
            public int dmPanningHeight;
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern bool EnumDisplaySettings(string lpszDeviceName, int iModeNum, ref DEVMODE lpDevMode);

        private int GetPrimaryMonitorRefreshRate()
        {
            DEVMODE vDevMode = new DEVMODE();
            vDevMode.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));

            if (EnumDisplaySettings(null, -1, ref vDevMode))
                return vDevMode.dmDisplayFrequency;

            return 60;
        }

        private void UpdateMonitorInfo()
        {
            TxtResolution.Text = $"{(int)SystemParameters.PrimaryScreenWidth}x{(int)SystemParameters.PrimaryScreenHeight}";
            Log($"Monitor info updated: Resolution={TxtResolution.Text}");
        }
        #endregion

        #region Config / Backup
        private void BtnSelectConfig_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog { Filter = "INI files (*.ini)|*.ini" };
            if (dlg.ShowDialog() == true)
            {
                configPath = dlg.FileName;
                TxtConfigPath.Text = $"Config: {configPath}";
                Log($"Config file selected: {configPath}");
            }
        }

        private void BtnSelectBackup_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog { Filter = "INI files (*.ini)|*.ini" };
            if (dlg.ShowDialog() == true)
            {
                backupPath = dlg.FileName;
                TxtBackupPath.Text = $"Backup: {backupPath}";
                Log($"Backup path selected: {backupPath}");
            }
        }
        #endregion

        #region Run / Rollback
        private void BtnRun_Click(object sender, RoutedEventArgs e)
        {
            TxtLog.Clear();
            MainProgress.Value = 0;
            TxtStatus.Text = "Status: running...";
            Log("=== RUN STARTED ===");

            bool rtxSupported = DetectDxrSupport();

            if (ChkRTX.IsChecked == true)
            {
                Log("Applying graphics preset...");
                ApplyPreset(rtxSupported);
            }

            MainProgress.Value = 50;

            if (ChkNetFix.IsChecked == true)
            {
                Log("Applying network optimizations...");
                ApplyNetFix();
            }

            MainProgress.Value = 80;

            if (ChkOptimize.IsChecked == true)
            {
                Log("Applying game optimizations...");
                ApplyOptimization();
            }

            if (ChkCpuBoost.IsChecked == true)
            {
                Log("Applying CPU Boost...");
                ApplyCpuBoost();
            }

            MainProgress.Value = 100;
            TxtStatus.Text = "Status: completed ✅";
            Log("=== RUN COMPLETED ===");
        }

        private void BtnRollback_Click(object sender, RoutedEventArgs e)
        {
            Log("Rollback initiated...");
            if (File.Exists(backupPath) && File.Exists(configPath))
            {
                File.Copy(backupPath, configPath, true);
                Log("Backup restored successfully ✅");
            }
            else
            {
                Log("Rollback failed: Backup or config file missing ⚠");
            }
        }
        #endregion

        #region Preset + INI
        private void ApplyPreset(bool rtxSupported)
        {
            Log("Checking config file...");
            if (!File.Exists(configPath))
            {
                Log("Config file missing! Aborting preset application ❌");
                return;
            }

            if (!string.IsNullOrEmpty(backupPath))
            {
                File.Copy(configPath, backupPath, true);
                Log($"Backup of config created at {backupPath}");
            }

            string preset = (CmbPreset.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "Medium";
            Log($"Selected preset: {preset}");

            string iniContent = GenerateOptimizedIni(rtxSupported, (int)SystemParameters.PrimaryScreenWidth,
                (int)SystemParameters.PrimaryScreenHeight, preset);

            File.WriteAllText(configPath, iniContent, Encoding.UTF8);
            Log($"Preset '{preset}' applied to config. RTX support: {rtxSupported}");

        }

        private string GenerateOptimizedIni(bool rtxSupported, int resX, int resY, string preset)
        {
            Log("Generating optimized INI content...");

            int viewDist = 3, texture = 3, foliage = 2, shadow = 2, aa = 3, effects = 2, post = 2, gi = 1, reflection = 2, shading = 1, resQuality = 100;
            float lodBias = 0f;

            string rtxGI = "Off";
            string scaling = "FSR3";
            string dlssMode = "Off";

            bool fpsLimitSection = false;

            switch (preset)
            {
                case "Low":
                    viewDist = 1; texture = 1; foliage = 0; shadow = 0; aa = 1; effects = 0; post = 0; gi = 0; reflection = 0; shading = 0; resQuality = 70; lodBias = 80f;
                    rtxGI = "Off"; scaling = "FSR3"; dlssMode = "Off";
                    break;
                case "Medium":
                    viewDist = 2; texture = 2; foliage = 1; shadow = 1; aa = 2; effects = 1; post = 1; gi = 1; reflection = 1; shading = 1; resQuality = 85; lodBias = 100f;
                    rtxGI = "DynamicLow"; scaling = "DLSS"; dlssMode = "DLAA";
                    break;
                case "High":
                    viewDist = 3; texture = 3; foliage = 2; shadow = 2; aa = 3; effects = 2; post = 2; gi = 1; reflection = 2; shading = 1; resQuality = 100; lodBias = 120f;
                    rtxGI = "DynamicMedium"; scaling = "DLSS"; dlssMode = "DLAA";
                    break;
                case "Epic":
                    viewDist = 4; texture = 4; foliage = 3; shadow = 3; aa = 4; effects = 3; post = 3; gi = 2; reflection = 3; shading = 2; resQuality = 120; lodBias = 150f;
                    rtxGI = "DynamicHigh"; scaling = "DLSS"; dlssMode = "DLAA";
                    break;
            }
            if (preset.StartsWith("Cinematic"))
            {
                Log("Cinematic preset detected – overriding selected values");

                viewDist = 4;
                texture = 4;
                foliage = 3;
                shadow = 4;
                aa = 4;
                effects = 4;
                post = 4;
                gi = 2;
                reflection = 3;
                shading = 2;
                resQuality = 100;
                lodBias = 160f;

                // UE natív FPS limit (csak Cinematic)
                fpsLimitSection = true;

                if (preset.Contains("RTX ON") && rtxSupported)
                {
                    Log("Cinematic RTX ON active");
                    rtxGI = "DynamicHigh";
                    scaling = "DLSS";
                    dlssMode = "DLAA";
                }
                else
                {
                    Log("Cinematic RTX OFF active");
                    rtxGI = "Off";
                    scaling = "FSR3";
                    dlssMode = "Off";
                }
            }

            Log($"Preset parameters: ViewDist={viewDist}, Texture={texture}, Foliage={foliage}, Shadow={shadow}, AA={aa}, Effects={effects}, Post={post}, GI={gi}, Reflection={reflection}, Shading={shading}, ResQuality={resQuality}, LODBias={lodBias}");
            Log($"Graphics settings: RTXGI={rtxGI}, Scaling={scaling}, DLSSMode={dlssMode}");

            var sb = new StringBuilder();
            sb.AppendLine("[/Script/Engine.GameUserSettings]");
            sb.AppendLine("bUseDesiredScreenHeight=False");
            sb.AppendLine();
            sb.AppendLine("[/Script/EmbarkUserSettings.EmbarkGameUserSettings]");
            sb.AppendLine("WindowPosY=-1");
            sb.AppendLine("bUseHDRDisplayOutput=False");
            sb.AppendLine($"WindowedResolutionSizeX={resX}");
            sb.AppendLine($"WindowedResolutionSizeY={resY}");
            sb.AppendLine($"ResolutionSizeX={resX}");
            sb.AppendLine($"ResolutionSizeY={resY}");
            sb.AppendLine($"DesiredScreenWidth={resX}");
            sb.AppendLine($"DesiredScreenHeight={resY}");
            sb.AppendLine($"bUseVSync=False");
            sb.AppendLine($"RTXGIQuality={rtxGI}");
            sb.AppendLine($"ResolutionScalingMethod={scaling}");
            sb.AppendLine($"DLSSMode={dlssMode}");
            sb.AppendLine($"sg.LODBias={lodBias}");
            sb.AppendLine();
            sb.AppendLine("[ScalabilityGroups]");
            sb.AppendLine($"sg.ViewDistanceQuality={viewDist}");
            sb.AppendLine($"sg.TextureQuality={texture}");
            sb.AppendLine($"sg.FoliageQuality={foliage}");
            sb.AppendLine($"sg.ShadowQuality={shadow}");
            sb.AppendLine($"sg.AntiAliasingQuality={aa}");
            sb.AppendLine($"sg.EffectsQuality={effects}");
            sb.AppendLine($"sg.PostProcessQuality={post}");
            sb.AppendLine($"sg.GlobalIlluminationQuality={gi}");
            sb.AppendLine($"sg.ReflectionQuality={reflection}");
            sb.AppendLine($"sg.ShadingQuality={shading}");
            sb.AppendLine($"sg.ResolutionQuality={resQuality}");

            Log("INI content generated successfully ✅");
            return sb.ToString();
        }
        #endregion

        #region RTX / DXR Detection
        private bool DetectDxrSupport()
        {
            Log("Detecting DXR / RTX support...");
            try
            {
                using var factory = DXGI.CreateDXGIFactory1<IDXGIFactory4>();
                for (int i = 0; factory.EnumAdapters1(i, out var adapter).Success; i++)
                {
                    var desc = adapter.Description1;
                    string gpuName = desc.Description.Trim();
                    Log($"Adapter found: {gpuName}");
                    if (gpuName.ToLower().Contains("rtx"))
                    {
                        Log("RTX GPU detected ✅");
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Log("DXR detection failed ❌: " + ex.Message);
                return false;
            }
            Log("No RTX GPU detected ⚠");
            return false;
        }
        #endregion

        #region Net & Optimization
        private void ApplyNetFix()
        {
            Log("Flushing DNS and resetting Winsock...");
            RunCmd("ipconfig /flushdns");
            RunCmd("netsh winsock reset");
            Log("Network optimization completed ✅");
        }

        private void ApplyOptimization()
        {
            Log("Setting ARC.exe process priority to High...");
            RunCmd("wmic process where name=\"ARC.exe\" CALL setpriority 128");
            RunCmd("wmic process where name=\"pioneergame.exe\" CALL setpriority 128"); //Steam version
            Log("Game priority optimization completed ✅");
        }

        private void RunCmd(string cmd)
        {
            try
            {
                Log($"Executing command: {cmd}");
                Process.Start(new ProcessStartInfo("cmd.exe", "/c " + cmd)
                {
                    CreateNoWindow = true,
                    UseShellExecute = false
                });
            }
            catch (Exception ex)
            {
                Log("Command execution failed ❌: " + ex.Message);
            }
        }
        #endregion

        #region CPU Boost
        private void ApplyCpuBoost()
        {
            try
            {
                Log("Applying CPU boost...");
                Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;
                Log("Process priority set to High");

                Process.Start("powercfg", "/setactive scheme_min");
                Log("Ultimate performance power plan activated");

                RunCmd("/c powercfg /hibernate off");
                Log("High precision timer / hibernate disabled");
            }
            catch (Exception ex)
            {
                Log("CPU boost failed ❌: " + ex.Message);
            }
        }
        #endregion

        #region CACHE CLEANING
        private void SafeDeleteDirectory(string path, string name)
        {
            try
            {
                if (Directory.Exists(path))
                {
                    Directory.Delete(path, true);
                    Log($"{name} cache deleted ✅ ({path})");
                }
                else
                {
                    Log($"{name} cache not found ⚠ ({path})");
                }
            }
            catch (Exception ex)
            {
                Log($"{name} cache deletion failed ❌: {ex.Message}");
            }
        }

        private void ClearArcRaidersCache()
        {
            string arcCache = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ARC Raiders");
            SafeDeleteDirectory(arcCache, "ARC Raiders");
        }

        private void ClearEpicGamesCache()
        {
            string epicCache = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "EpicGamesLauncher", "Saved", "webcache");
            SafeDeleteDirectory(epicCache, "Epic Games");
        }

        private void ClearSteamCache()
        {
            string steamCache = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Steam", "htmlcache");
            SafeDeleteDirectory(steamCache, "Steam");
        }

        private void ClearNvidiaCache()
        {
            string nvidiaLocal = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NVIDIA");
            string nvidiaProgramData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "NVIDIA Corporation", "NV_Cache");
            SafeDeleteDirectory(nvidiaLocal, "NVIDIA Local");
            SafeDeleteDirectory(nvidiaProgramData, "NVIDIA ProgramData");
        }

        private void ClearAmdCache()
        {
            string amdLocal = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AMD");
            string amdProgramData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "AMD");
            SafeDeleteDirectory(amdLocal, "AMD Local");
            SafeDeleteDirectory(amdProgramData, "AMD ProgramData");
        }

        private void Menu_ClearAllCaches(object sender, RoutedEventArgs e)
        {
            Log("All caches clearing initiated...");
            ClearArcRaidersCache();
            ClearEpicGamesCache();
            ClearSteamCache();
            ClearNvidiaCache();
            ClearAmdCache();
            Log("All caches cleared ✅");
        }
        #endregion

        #region Log
        private void Log(string msg)
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
            TxtLog.AppendText($"[{timestamp}] {msg}{Environment.NewLine}");
            TxtLog.ScrollToEnd();
        }
        #endregion
    }
}
